"use strict";
exports.id = 498;
exports.ids = [498];
exports.modules = {

/***/ 1836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ ApiConstants)
/* harmony export */ });
const ApiConstants = {
    baseUrl: "http://185.18.214.5/",
    timeOut: 25000
};


/***/ }),

/***/ 2445:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1836);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const BackEndReq = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create();
BackEndReq.defaults.baseURL = _constants__WEBPACK_IMPORTED_MODULE_1__/* .ApiConstants.baseUrl */ .G.baseUrl;
BackEndReq.defaults.timeout = _constants__WEBPACK_IMPORTED_MODULE_1__/* .ApiConstants.timeOut */ .G.timeOut;
BackEndReq.defaults.headers = {
    Accept: "application/json",
    "Content-Type": "application/json;charset=UTF-8"
};
BackEndReq.setToken = function(token) {
    BackEndReq.defaults.headers = {
        Accept: "application/json",
        "Content-Type": "application/json;charset=UTF-8",
        Authorization: ("Bearer " + token) ?? "niiiiiss"
    };
};
BackEndReq.interceptors.response.use((response)=>{
    return response;
}, (err)=>{
    return Promise.reject(err);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackEndReq);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3498:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ai": () => (/* binding */ getProfile),
/* harmony export */   "Fb": () => (/* binding */ registerByPhoneAndPasswordRequest),
/* harmony export */   "RO": () => (/* binding */ registerByEmailAndPasswordRequest),
/* harmony export */   "Rc": () => (/* binding */ loginByPhoneAndPasswordRequest),
/* harmony export */   "V1": () => (/* binding */ sendOtpRequestToEmail),
/* harmony export */   "WD": () => (/* binding */ sendOtpRequest),
/* harmony export */   "el": () => (/* binding */ loginByEmailAndPasswordRequest),
/* harmony export */   "gY": () => (/* binding */ requestLandRequest)
/* harmony export */ });
/* unused harmony export getUserListRequest */
/* harmony import */ var _Api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2445);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Api__WEBPACK_IMPORTED_MODULE_0__]);
_Api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const loginByPhoneAndPasswordRequest = async (params)=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`app/auth/login`, params);
};
const loginByEmailAndPasswordRequest = async (params)=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`app/auth/email/login`, params);
};
const sendOtpRequest = async (params)=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`app/auth/register/checkexsistuser`, params);
};
const sendOtpRequestToEmail = async (params)=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`app/auth/email/register/checkexsistuser`, params);
};
const registerByPhoneAndPasswordRequest = async (params)=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`app/auth/register/registercomplete`, params);
};
const registerByEmailAndPasswordRequest = async (params)=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`app/auth/email/register/registercomplete`, params);
};
const requestLandRequest = async (params)=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`app/landrequest/req`, params);
};
const getUserListRequest = async (params)=>{
    return await BackEndReq.get(`admin/userlist?page`, {
        params: params
    });
};
const getProfile = async ()=>{
    return await _Api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`app/auth/user`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;