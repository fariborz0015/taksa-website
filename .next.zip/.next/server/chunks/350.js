"use strict";
exports.id = 350;
exports.ids = [350];
exports.modules = {

/***/ 1057:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _iconify_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5566);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_iconify_react__WEBPACK_IMPORTED_MODULE_1__]);
_iconify_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Button = (props)=>{
    const { title , isLoading , children  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        disabled: isLoading || props?.disabled,
        ...props,
        className: `customDisablebutton w-full flex items-center justify-center h-14 transition-all bg-primaryLight hover:bg-primary text-white rounded-lg ${props?.className ?? ""}`,
        children: [
            isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_iconify_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                icon: "eos-icons:loading",
                width: 28
            }) : title,
            !isLoading && children
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3199:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__]);
react_toastify__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// this hook will do like a wraper for react-toastify
const useAlert = ()=>{
    const initialsOption = {};
    const alerts = {
        // make a success toast notification
        success: (message, options = initialsOption)=>{
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.success(message, options);
        },
        // make a warning toast notification
        warning: (message, options = initialsOption)=>{
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.warning(message, options);
        },
        // make a warning toast notification
        info: (message, options = initialsOption)=>{
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.info(message, options);
        },
        // make a error toast notification
        error: (message, options = initialsOption)=>{
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(message, options);
        },
        // make a custom toast notification
        custom: (message, options = initialsOption)=>{
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast)(message, options);
        }
    };
    return alerts;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAlert);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;