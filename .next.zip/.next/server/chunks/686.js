"use strict";
exports.id = 686;
exports.ids = [686];
exports.modules = {

/***/ 2686:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _service_Requests__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3498);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_service_Requests__WEBPACK_IMPORTED_MODULE_1__]);
_service_Requests__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const useRequestLand = ()=>{
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    // send detected params from data state to api for login
    // add this function to login button
    const submit = async (params = data)=>{
        // change loading state to true before request sending
        setIsLoading(true);
        // send request as async function
        const response = await (0,_service_Requests__WEBPACK_IMPORTED_MODULE_1__/* .requestLandRequest */ .gY)(params);
        // change losidng state to false after request sended and response recive
        setIsLoading(false);
        return response;
    };
    return {
        data,
        // get new data and replace and merge with existing data
        setData: (params)=>setData((prev)=>({
                    ...prev,
                    ...params
                })),
        resetData: (params)=>setData(params),
        isLoading,
        setIsLoading,
        submit
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useRequestLand);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;